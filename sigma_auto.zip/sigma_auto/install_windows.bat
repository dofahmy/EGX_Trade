@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === تسطيب المكتبات ===
python -m pip install -r requirements.txt
python -m playwright install chromium
echo.
echo === حفظ بيانات الدخول وتجربة سيجما ===
python sigma_auto.py setup
echo.
echo === تحميل آخر ٢٥ يوم للأرشيف (ممكن ياخد ربع ساعة) ===
python sigma_auto.py backfill
echo.
echo === تسجيل المواعيد في جدولة ويندوز ===
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0schedule_windows.ps1"
echo.
echo خلصت. المواعيد: ١٢:٠٢ الضهر، و٣:٣٠ العصر، و٦ المغرب، من الأحد للخميس.
pause
