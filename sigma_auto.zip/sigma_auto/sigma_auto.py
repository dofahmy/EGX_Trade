# -*- coding: utf-8 -*-
"""
تحميل صفقات البورصة المصرية من سيجما أوتوماتيك، ورفعها على التطبيق، وحساب إشارة الساعة ١٢.

الأوامر:
    python sigma_auto.py setup        حفظ بيانات الدخول (مرة واحدة) وتجربة الدخول
    python sigma_auto.py test         يجرب الدخول ويحمّل سهم واحد بس للتأكد
    python sigma_auto.py eod          بعد الجلسة: يحمّل اليوم كامل (وأي يوم فات) ويرفعه على التطبيق
    python sigma_auto.py noon         الساعة ١٢: يحمّل صفقات لحد ١٢ ويحسب الإشارة ويبعتها
    python sigma_auto.py day 2026-11-10   يحمّل يوم معيّن ويرفعه
    python sigma_auto.py backfill     يحمّل آخر ٢٥ يوم للأرشيف (مرة واحدة بعد التسطيب)

بيانات الدخول بتتحفظ في خزنة الجهاز (مدير بيانات الاعتماد في ويندوز / سلسلة المفاتيح في الماك)،
مش في أي ملف، ومش بتتكتب في السجل.
"""
import sys, os, json, time, io, zipfile, datetime as dt, getpass, traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
CFG_FILE = HERE / 'config.json'
DATA = HERE / 'data'            # أرشيف ملفات الأيام الكاملة
NOON = HERE / 'noon'            # ملفات الساعة ١٢
LOGS = HERE / 'logs'
DEBUG = HERE / 'debug'
PROFILE = HERE / 'chrome_profile'
for p in (DATA, NOON, LOGS, DEBUG):
    p.mkdir(exist_ok=True)

KR = 'sigma_auto'               # اسم الخانة في خزنة الجهاز

DEFAULT_CFG = {
    "sigma_url": "https://www.sigma-cap.com/",
    "app_url": "https://egxtrade-production.up.railway.app",
    "parallel": 4,
    "wait_ms": 250,
    "headless": False,
    "signal_min_stocks": 10,
    "signal_buyer_share": 0.6,
    "signal_min_value": 1000000,
    "signal_top": 3,
    "catch_up_days": 10,
    "selectors": {
        "user": "", "pass1": "", "submit1": "",
        "pass2": "", "submit2": ""
    }
}


def cfg():
    c = json.loads(json.dumps(DEFAULT_CFG))
    if CFG_FILE.exists():
        u = json.loads(CFG_FILE.read_text(encoding='utf-8'))
        sel = u.pop('selectors', {})
        c.update(u)
        c['selectors'].update(sel)
    return c


def log(*a):
    s = dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + ' ' + ' '.join(str(x) for x in a)
    print(s, flush=True)
    with open(LOGS / (dt.date.today().strftime('%Y-%m') + '.log'), 'a', encoding='utf-8') as f:
        f.write(s + '\n')


# ---------------- خزنة الجهاز ----------------

def secret(name):
    import keyring
    return keyring.get_password(KR, name)


def setup():
    import keyring
    print('هتكتبي بيانات دخول سيجما هنا. مش هتظهر وانتي بتكتبي، وهتتحفظ في خزنة الجهاز بس.')
    u = input('اسم المستخدم: ').strip()
    p1 = getpass.getpass('كلمة السر (الشاشة الأولى): ')
    p2 = getpass.getpass('كلمة الدخول (الشاشة التانية): ')
    keyring.set_password(KR, 'user', u)
    keyring.set_password(KR, 'pass1', p1)
    keyring.set_password(KR, 'pass2', p2)
    ap = getpass.getpass('كلمة سر التطبيق على ريلواي (لو مش متحطوطة سيبيها فاضية واضغطي إنتر): ')
    keyring.set_password(KR, 'app_password', ap or '')
    tg = input('عاوزة الإشارة توصلك على تيليجرام؟ اكتبي توكن البوت (أو سيبيها فاضية): ').strip()
    if tg:
        keyring.set_password(KR, 'tg_token', tg)
        keyring.set_password(KR, 'tg_chat', input('رقم المحادثة (chat id): ').strip())
    print('اتحفظ. دلوقتي هجرب الدخول...')
    test()


# ---------------- المتصفح والدخول ----------------

class Sigma:
    def __init__(self, c):
        self.c = c
        self.sess = None
        self.seen = None

    def __enter__(self):
        from playwright.sync_api import sync_playwright
        self.pw = sync_playwright().start()
        args = dict(user_data_dir=str(PROFILE), headless=self.c['headless'],
                    viewport={'width': 1280, 'height': 850}, locale='ar-EG')
        try:
            self.ctx = self.pw.chromium.launch_persistent_context(channel='chrome', **args)
        except Exception:
            self.ctx = self.pw.chromium.launch_persistent_context(**args)
        self.page = self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
        # أي طلب فيه u_sess بنمسك الجلسة منه
        def on_req(r):
            u = r.url
            if 'u_sess=' in u:
                self.seen = u.split('u_sess=')[1].split('&')[0]
        self.ctx.on('request', on_req)
        return self

    def __exit__(self, *a):
        try:
            self.ctx.close()
        finally:
            self.pw.stop()

    def shot(self, tag):
        """صورة للصفحة لو حاجة فشلت، عشان نعرف المشكلة (من غير أي بيانات دخول)."""
        try:
            f = DEBUG / f"{dt.datetime.now():%Y%m%d_%H%M%S}_{tag}.png"
            self.page.screenshot(path=str(f), full_page=True)
            log('صورة الصفحة اتحفظت:', f.name)
        except Exception:
            pass

    def _visible(self, sel):
        try:
            for el in self.page.locator(sel).all():
                if el.is_visible():
                    return el
        except Exception:
            pass
        return None

    def _submit(self, sel, field):
        b = self._visible(sel) if sel else None
        b = b or self._visible('button[type=submit], input[type=submit], input[type=image], button:has-text("دخول"), button:has-text("Login"), a:has-text("دخول"), a:has-text("Login")')
        if b:
            b.click()
        else:
            field.press('Enter')

    def login(self):
        s = self.c['selectors']
        log('بدخل على سيجما...')
        self.page.goto(self.c['sigma_url'], wait_until='domcontentloaded', timeout=60000)
        self.page.wait_for_timeout(3000)
        if self.check():
            log('الدخول كان شغال من قبل')
            return True
        p1 = self._visible(s['pass1'] or 'input[type=password]')
        if not p1:
            self.shot('no_login_form')
            raise RuntimeError('مش لاقي خانة كلمة السر في صفحة سيجما')
        u = self._visible(s['user'] or 'input[type=text], input[type=email], input:not([type])')
        if u:
            u.fill(secret('user') or '')
        p1.fill(secret('pass1') or '')
        self._submit(s['submit1'], p1)
        self.page.wait_for_timeout(4000)
        # الشاشة التانية: كلمة الدخول
        p2 = None
        for _ in range(10):
            p2 = self._visible(s['pass2'] or 'input[type=password]')
            if p2:
                break
            self.page.wait_for_timeout(1000)
        if p2:
            p2.fill(secret('pass2') or '')
            self._submit(s['submit2'], p2)
            self.page.wait_for_timeout(5000)
        for _ in range(20):
            if self.check():
                log('دخلت تمام')
                return True
            self.page.wait_for_timeout(1500)
        self.shot('login_failed')
        raise RuntimeError('الدخول ما نجحش')

    def check(self):
        """الجلسة شغالة؟ بنجرب نجيب صفقات سهم معروف."""
        cand = self.seen
        if not cand:
            try:
                cand = self.page.evaluate("""() => {
                    const h = performance.getEntriesByType('resource').map(e => e.name).concat([location.href])
                              .find(u => /u_sess=/.test(u));
                    return h ? h.match(/u_sess=([^&]+)/)[1] : null; }""")
            except Exception:
                cand = None
        if not cand or 'sigma-cap.com' not in self.page.url:
            return False
        r = self.fetch_many([('EGS60121C010', last_weekday().strftime('%d-%m-%Y'))], cand)
        if r and r[0] is not None:
            self.sess = cand
            return True
        return False

    def fetch_many(self, items, sess=None):
        """بيرجع لكل (أيزن، تاريخ): نص الملف، أو None لو الرد مش ملف صفقات (الجلسة خلصت)."""
        return self.page.evaluate("""async ([items, sess, par, wait]) => {
            const out = new Array(items.length); let next = 0;
            const sleep = ms => new Promise(r => setTimeout(r, ms));
            const one = async i => {
                const [isin, dat] = items[i];
                for (let k = 0; k < 2; k++) {
                  try {
                    const r = await fetch(`/main/TRADE.show_stock_trades?u_sess=${sess}&eq_code_p=${isin}&dat=${dat}`, {credentials: 'include'});
                    const t = await r.text();
                    const cd = r.headers.get('content-disposition') || '';
                    const m = cd.match(/filename="?([A-Za-z0-9.]+)_Trades/);
                    out[i] = t.trim().startsWith('Date') ? [t, m ? m[1] : null] : null;
                    break;
                  } catch (e) { out[i] = null; await sleep(2000); }
                }
                await sleep(wait);
            };
            const worker = async () => { while (next < items.length) await one(next++); };
            await Promise.all(Array.from({length: par}, worker));
            return out; }""", [items, sess or self.sess, self.c['parallel'], self.c['wait_ms']])

    def day(self, date, isin_map):
        """يحمّل يوم كامل لكل الأسهم. لو الجلسة وقعت في النص بيدخل تاني ويكمّل."""
        dat = date.strftime('%d-%m-%Y')
        isins = list(isin_map)
        res = {}
        todo = isins[:]
        for attempt in range(4):
            if not todo:
                break
            if attempt and not self.login():
                break
            failed = []
            for k in range(0, len(todo), 40):
                chunk = todo[k:k + 40]
                got = self.fetch_many([(i, dat) for i in chunk])
                bad = [i for i, g in zip(chunk, got) if g is None]
                for i, g in zip(chunk, got):
                    if g is not None:
                        res[i] = g
                if len(bad) > len(chunk) // 2:      # أغلب الطلبات فشلت = الجلسة خلصت
                    failed += bad + [x for x in todo[k + 40:]]
                    log(f'{dat}: الجلسة وقعت عند {len(res)} سهم، هدخل تاني وأكمّل')
                    break
                failed += bad
            todo = failed
        if todo:
            log(f'{dat}: {len(todo)} سهم ما اتحملوش بعد كذا محاولة')
        lines = ['Symbol,ISIN,Date,Time,Ticket No.,Volume,Price,Value']
        stocks = 0
        for isin in isins:
            if isin not in res:
                continue
            txt, sym = res[isin]
            sym = sym or isin_map.get(isin) or isin
            if sym and not isin_map.get(isin):
                isin_map[isin] = sym
            rows = [l for l in txt.strip().splitlines()[1:] if l.strip()]
            if rows:
                stocks += 1
            lines += [f'{sym},{isin},{l}' for l in rows]
        return '\n'.join(lines) + '\n', stocks, len(lines) - 1, len(todo)


# ---------------- أدوات ----------------

def last_weekday(d=None):
    d = d or dt.date.today()
    d -= dt.timedelta(days=1)
    while d.weekday() in (4, 5):        # الجمعة والسبت
        d -= dt.timedelta(days=1)
    return d


def trading_days_back(n):
    out, d = [], dt.date.today()
    while len(out) < n:
        if d.weekday() not in (4, 5):
            out.append(d)
        d -= dt.timedelta(days=1)
    return out


def load_map():
    return json.loads((HERE / 'isin_map.json').read_text(encoding='utf-8'))


def save_map(m):
    (HERE / 'isin_map.json').write_text(json.dumps(m, ensure_ascii=False, indent=0, sort_keys=True), encoding='utf-8')


def upload(c, date, csv_text):
    import requests
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr(f'sigma_trades_{date}.csv', csv_text)
    ap = secret('app_password') or ''
    auth = ('user', ap) if ap else None
    for k in range(3):
        try:
            r = requests.post(c['app_url'].rstrip('/') + '/upload',
                              files={'file': (f'sigma_trades_{date}.zip', buf.getvalue(), 'application/zip')},
                              data={'date': str(date)}, auth=auth, allow_redirects=False, timeout=300)
            if r.status_code in (200, 302, 303):
                log(f'{date}: اترفع على التطبيق')
                return True
            log(f'{date}: التطبيق رد {r.status_code}')
        except Exception as e:
            log(f'{date}: الرفع فشل: {e}')
        time.sleep(20)
    return False


def telegram(text):
    tok, chat = secret('tg_token'), secret('tg_chat')
    if not tok or not chat:
        return
    import requests
    try:
        requests.post(f'https://api.telegram.org/bot{tok}/sendMessage',
                      data={'chat_id': chat, 'text': text}, timeout=30)
    except Exception as e:
        log('تيليجرام فشل:', e)


class Lock:
    def __enter__(self):
        self.f = HERE / '.running'
        if self.f.exists() and time.time() - self.f.stat().st_mtime < 3 * 3600:
            log('فيه تشغيل تاني شغال، هقفل')
            sys.exit(0)
        self.f.write_text(str(os.getpid()))

    def __exit__(self, *a):
        self.f.unlink(missing_ok=True)


# ---------------- الأوامر ----------------

def run_days(c, days, do_upload=True):
    m = load_map()
    with Sigma(c) as s:
        s.login()
        for d in days:
            csv, stocks, trades, missing = s.day(d, m)
            save_map(m)
            if trades == 0:
                log(f'{d}: مفيش صفقات (أجازة غالبًا)')
                (DATA / f'{d}.empty').write_text('')
                continue
            f = DATA / f'sigma_trades_{d}.csv'
            f.write_text(csv, encoding='utf-8')
            log(f'{d}: {stocks} سهم و{trades} صفقة' + (f'، ناقص {missing} سهم' if missing else ''))
            if missing:
                f.with_suffix('.partial').write_text(str(missing))
            else:
                f.with_suffix('.partial').unlink(missing_ok=True)
            if do_upload:
                upload(c, d, csv)


def eod():
    c = cfg()
    now = dt.datetime.now()
    today = dt.date.today()
    days = []
    for d in sorted(trading_days_back(c['catch_up_days'])):
        if d == today and now.hour * 60 + now.minute < 15 * 60 + 15:
            continue                     # الجلسة لسه ما خلصتش
        f = DATA / f'sigma_trades_{d}.csv'
        if (f.exists() and not f.with_suffix('.partial').exists()) or (DATA / f'{d}.empty').exists():
            continue
        days.append(d)
    if not days:
        log('مفيش أيام ناقصة')
        return
    log('هحمّل:', ', '.join(map(str, days)))
    run_days(c, days)


def backfill():
    """يحمّل آخر ٢٥ يوم تداول للأرشيف (من غير رفع)، عشان إشارة الساعة ١٢ تلاقي أيام قديمة."""
    c = cfg()
    today = dt.date.today()
    days = [d for d in sorted(trading_days_back(26)) if d < today
            and not (DATA / f'sigma_trades_{d}.csv').exists() and not (DATA / f'{d}.empty').exists()]
    if days:
        log('هحمّل للأرشيف:', len(days), 'يوم')
        run_days(c, days, do_upload=False)


def noon():
    import pandas as pd, numpy as np
    c = cfg()
    today = dt.date.today()
    if today.weekday() in (4, 5):
        return
    m = load_map()
    # لازم يكون عندنا الأيام اللي فاتت كاملة (لحساب حجم امبارح والسيولة)
    need = [d for d in sorted(trading_days_back(25)) if d < today
            and not (DATA / f'sigma_trades_{d}.csv').exists() and not (DATA / f'{d}.empty').exists()]
    with Sigma(c) as s:
        s.login()
        for d in need:
            csv, stocks, trades, _ = s.day(d, m)
            if trades:
                (DATA / f'sigma_trades_{d}.csv').write_text(csv, encoding='utf-8')
            else:
                (DATA / f'{d}.empty').write_text('')
        csv, stocks, trades, missing = s.day(today, m)
        save_map(m)
    if not trades:
        log('مفيش صفقات النهارده لحد دلوقتي (أجازة؟ أو سيجما مش بيدي صفقات اليوم وهو شغال)')
        return
    (NOON / f'noon_{today}.csv').write_text(csv, encoding='utf-8')
    msg = signal(c, today, pd.read_csv(io.StringIO(csv)))
    log(msg)
    (NOON / f'signal_{today}.txt').write_text(msg, encoding='utf-8')
    telegram(msg)


def _prep(df):
    df = df.drop_duplicates(['Symbol', 'Ticket No.']).sort_values(['Symbol', 'Ticket No.'])
    return df


def signal(c, today, d):
    """نفس قواعد الاختبار: حجم الساعة الأولى ≥ حجم امبارح كله، والمشتري ≥ ٦٠٪، في ١٠ أسهم أو أكتر."""
    import pandas as pd, numpy as np
    d = _prep(d)
    d = d[d['Time'].str.startswith('10:') | d['Time'].str.startswith('11:')]
    hist = []
    for f in sorted(DATA.glob('sigma_trades_*.csv')):
        day = f.stem.split('_')[-1]
        if day < str(today):
            hist.append(f)
    hist = hist[-20:]
    if not hist:
        return 'مفيش أيام قديمة في الأرشيف، مش هقدر أحسب الإشارة'
    vals = []
    for f in hist:
        h = _prep(pd.read_csv(f, usecols=['Symbol', 'Ticket No.', 'Volume', 'Price', 'Value']))
        vals.append(h.groupby('Symbol').agg(v=('Value', 'sum'), vol=('Volume', 'sum'), c=('Price', 'last')))
    prev = vals[-1]
    med = pd.concat([v['v'] for v in vals], axis=1).fillna(0).median(axis=1)
    g = d.groupby('Symbol')
    s = np.sign(g['Price'].diff()).replace(0, np.nan)
    d = d.assign(s=s.groupby(d['Symbol']).ffill().fillna(0))
    h1 = d[d['Time'].str.startswith('10:')]
    a = pd.DataFrame({
        'h1vol': h1.groupby('Symbol')['Volume'].sum(),
        'h1b': h1[h1.s > 0].groupby('Symbol')['Volume'].sum(),
        'h1s': h1[h1.s < 0].groupby('Symbol')['Volume'].sum(),
        'o': g['Price'].first(), 'p12': g['Price'].last(),
    }).fillna({'h1b': 0, 'h1s': 0})
    a = a.join(prev[['vol', 'c']], how='inner').join(med.rename('med'))
    a['bsh'] = a.h1b / (a.h1b + a.h1s)
    a['g12'] = a.p12 / a.c - 1
    a['gap'] = a.o / a.c - 1
    ok = (a.vol > 0) & (a.h1vol >= a.vol) & (a.bsh >= c['signal_buyer_share']) \
         & (a.med >= c['signal_min_value']) & (a.gap.abs() <= 0.2)
    sig = a[ok].sort_values('g12', ascending=False)
    n = len(sig)
    head = f'إشارة الساعة ١٢ — {today}\nعدد الأسهم اللي المشتري مسيطر على ساعتها الأولى: {n}\n'
    if n < c['signal_min_stocks']:
        return head + f'مش يوم إشارة (محتاج {c["signal_min_stocks"]} أو أكتر)'
    top = sig.head(c['signal_top'])
    lines = [f'{i+1}. {r.Index}  {r.g12*100:+.1f}٪ لحد ١٢ · المشتري {r.bsh*100:.0f}٪ · حجم الساعة الأولى {r.h1vol/r.vol:.1f}× امبارح'
             for i, r in enumerate(top.itertuples())]
    rest = ' '.join(sig.index[c['signal_top']:])
    return head + '✅ يوم إشارة\nأعلى ' + str(c['signal_top']) + ':\n' + '\n'.join(lines) + \
        (f'\nالباقي: {rest}' if rest else '') + '\n(للمتابعة على الورق، مش ترشيح شراء)'


def test():
    c = cfg()
    m = load_map()
    with Sigma(c) as s:
        s.login()
        d = last_weekday()
        got = s.fetch_many([('EGS60121C010', d.strftime('%d-%m-%Y'))])
        if got and got[0]:
            n = len(got[0][0].strip().splitlines()) - 1
            log(f'التجربة نجحت: {got[0][1] or "COMI"} يوم {d}: {n} صفقة')
        else:
            s.shot('test_failed')
            log('التجربة فشلت')


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else ''
    try:
        if cmd == 'setup':
            setup()
        elif cmd == 'test':
            test()
        elif cmd in ('eod', 'noon', 'day', 'backfill'):
            with Lock():
                if cmd == 'eod':
                    eod()
                elif cmd == 'noon':
                    noon()
                elif cmd == 'backfill':
                    backfill()
                else:
                    run_days(cfg(), [dt.date.fromisoformat(x) for x in sys.argv[2:]])
        else:
            print(__doc__)
    except Exception as e:
        log('خطأ:', e)
        log(traceback.format_exc())
        if cmd in ('eod', 'noon'):
            telegram(f'تحميل سيجما ({cmd}) فشل: {e}')
        sys.exit(1)


if __name__ == '__main__':
    main()
