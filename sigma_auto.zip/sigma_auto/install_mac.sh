#!/bin/bash
# تسطيب على الماك: المكتبات، وبيانات الدخول، و٣ مواعيد من الأحد للخميس.
cd "$(dirname "$0")"
DIR="$(pwd)"
PY="$(command -v python3)"
"$PY" -m pip install -r requirements.txt
"$PY" -m playwright install chromium
"$PY" sigma_auto.py setup
"$PY" sigma_auto.py backfill

mkdir -p ~/Library/LaunchAgents
make_plist () {   # الاسم، الساعة، الدقيقة، الأمر
  F=~/Library/LaunchAgents/com.sigma.$1.plist
  {
  echo '<?xml version="1.0" encoding="UTF-8"?>'
  echo '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">'
  echo '<plist version="1.0"><dict>'
  echo "<key>Label</key><string>com.sigma.$1</string>"
  echo "<key>ProgramArguments</key><array><string>$PY</string><string>$DIR/sigma_auto.py</string><string>$4</string></array>"
  echo "<key>WorkingDirectory</key><string>$DIR</string>"
  echo '<key>StartCalendarInterval</key><array>'
  for d in 0 1 2 3 4; do echo "<dict><key>Weekday</key><integer>$d</integer><key>Hour</key><integer>$2</integer><key>Minute</key><integer>$3</integer></dict>"; done
  echo '</array>'
  echo "<key>StandardOutPath</key><string>$DIR/logs/launchd.log</string>"
  echo "<key>StandardErrorPath</key><string>$DIR/logs/launchd.log</string>"
  echo '</dict></plist>'
  } > "$F"
  launchctl unload "$F" 2>/dev/null
  launchctl load "$F"
  echo "اتسجل: $1 الساعة $2:$3"
}
mkdir -p logs
make_plist noon 12 2 noon
make_plist eod 15 30 eod
make_plist retry 18 0 eod
echo "عشان الماك يصحى لوحده قبل الضهر (محتاج كلمة سر الجهاز):"
sudo pmset repeat wakeorpoweron UMTWR 11:55:00
