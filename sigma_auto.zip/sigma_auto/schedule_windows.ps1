﻿# بيسجل ٣ مواعيد في جدولة المهام في ويندوز، من الأحد للخميس.
# الجهاز بيصحى لوحده للميعاد، ولو كان مقفول وقت الميعاد بيشتغل أول ما يفتح.
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$py = (Get-Command python).Source
$days = 'Sunday','Monday','Tuesday','Wednesday','Thursday'
$jobs = @(
  @{ name = 'Sigma 1 noon';  at = '12:02'; arg = 'noon' },
  @{ name = 'Sigma 2 eod';   at = '15:30'; arg = 'eod' },
  @{ name = 'Sigma 3 retry'; at = '18:00'; arg = 'eod' }
)
foreach ($j in $jobs) {
  $a = New-ScheduledTaskAction -Execute $py -Argument "`"$dir\sigma_auto.py`" $($j.arg)" -WorkingDirectory $dir
  $t = New-ScheduledTaskTrigger -Weekly -DaysOfWeek $days -At $j.at
  $s = New-ScheduledTaskSettingsSet -WakeToRun -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 2)
  Register-ScheduledTask -TaskName $j.name -Action $a -Trigger $t -Settings $s -Force | Out-Null
  Write-Host "اتسجل: $($j.name) الساعة $($j.at)"
}
